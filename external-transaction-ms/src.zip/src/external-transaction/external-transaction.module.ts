import { Module } from '@nestjs/common';
import { ExternalTransactionService } from './external-transaction.service';
import { TransactionController } from './external-transaction.controller';
import { MasterTableService } from 'src/master-table/master-table.service';
import { MasterTableModule } from 'src/master-table/master-table.module';
import { KafkaModule } from 'src/transports/kafka.module';
import { DatabaseModule } from 'src/config';

@Module({
  controllers: [TransactionController],
  providers: [ExternalTransactionService],
  imports: [DatabaseModule, MasterTableModule, KafkaModule],
})
export class TransactionModule {}
