import { Inject, Injectable, Logger, OnModuleInit } from '@nestjs/common';
import { CreateTransactionDto } from './dto/create-transaction.dto';
import { UpdateTransactionDto } from './dto/update-transaction.dto';
import { MasterTableService } from 'src/master-table/master-table.service';
import { MasterTableConstant } from 'src/constants';
import { FindOneTransactionDto } from './dto/find-one-trasaction.dto';
import { ANTI_FRAUD_SERVICE, DatabaseService } from 'src/config';
import { ClientKafka } from '@nestjs/microservices';

@Injectable()
export class ExternalTransactionService {
  private readonly logger = new Logger('ExternalTransactionService');

  constructor(
    private readonly db: DatabaseService,
    private readonly masterTableService: MasterTableService,
    @Inject(ANTI_FRAUD_SERVICE) private readonly kafkaClient: ClientKafka,
  ) {}
  async create(createTransactionDto: CreateTransactionDto) {
    const {
      accountExternalIdCredit,
      accountExternalIdDebit,
      tranferTypeId,
      value,
    } = createTransactionDto;

    const status = await this.masterTableService.findFirst({
      parentId: MasterTableConstant.TransactionStatus,
    });

    const type = await this.masterTableService.findFirst({
      parentId: MasterTableConstant.TransactionType,
    });

    const record = await this.db.externalTransaction.create({
      data: {
        externalCreditAccountId: accountExternalIdCredit,
        externalDebitAccountId: accountExternalIdDebit,
        value: value,
        statusId: status.id,
        typeId: type.id,
        transferTypeId: tranferTypeId,
      },
    });

    this.kafkaClient.emit(
      'verify.transaction',
      JSON.stringify({ ...record, status: status.name }),
    );

    console.log({ record });

    return JSON.stringify(record);
  }

  async findAll() {
    const records = await this.db.externalTransaction.findMany();

    return JSON.stringify(records);
  }

  async findOne(findOneTransactionDto: FindOneTransactionDto) {
    const {
      transactionExternalId,
      transactionStatus,
      transactionType,
      value,
      createdAt,
    } = findOneTransactionDto;

    const status = await this.masterTableService.findOne({
      id: transactionStatus.id,
      name: transactionStatus.name,
      parentId: MasterTableConstant.TransactionStatus,
    });

    const type = await this.masterTableService.findOne({
      id: transactionType.id,
      name: transactionType.name,
      parentId: MasterTableConstant.TransactionType,
    });

    const queryResponse = await this.db.$queryRaw`
    SELECT * FROM "ExternalTransaction"
    WHERE ("ExternalTransaction"."id" = ${transactionExternalId}
      AND ("ExternalTransaction"."statusId" = ${status?.id}
      AND "ExternalTransaction"."typeId" = ${type?.id}
      AND "ExternalTransaction"."value" = ${value}
      AND DATE("ExternalTransaction"."createdAt") = DATE(${createdAt})
      ))
    `;

    const record = queryResponse?.[0];

    if (!record) throw new Error(`Transaction record not found`);

    return JSON.stringify(record);
  }

  async update(updateTransactionDto: UpdateTransactionDto) {
    console.log({ updateTransactionDto });

    const status = await this.masterTableService.findOne({
      parentId: MasterTableConstant.TransactionStatus,
      name: updateTransactionDto.status,
    });

    const record = await this.db.externalTransaction.update({
      data: {
        statusId: status?.id,
        updatedAt: new Date(),
      },
      where: {
        id: updateTransactionDto.id,
      },
    });

    return record;
  }

  remove(id: string) {
    return `This action removes a #${id} transaction`;
  }
}
