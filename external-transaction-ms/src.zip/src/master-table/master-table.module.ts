import { Module } from '@nestjs/common';
import { MasterTableController } from './master-table.controller';
import { MasterTableService } from './master-table.service';
import { DatabaseModule, DatabaseService } from 'src/config';

@Module({
  controllers: [MasterTableController],
  providers: [MasterTableService, DatabaseService],
  exports: [MasterTableService],
  imports: [DatabaseModule],
})
export class MasterTableModule {}
