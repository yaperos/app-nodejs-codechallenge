export class MasterTableController {}
