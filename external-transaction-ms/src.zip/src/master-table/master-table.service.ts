import { Logger } from '@nestjs/common';
import { FindOneMasterTableDto } from './dto/find-one-master-table.dto';
import { FindFirstMasterTableDto } from './dto/find-first-master-table.dto';
import { DatabaseService } from 'src/config';

export class MasterTableService {
  private readonly logger = new Logger('MasterTableService');

  constructor(private readonly db: DatabaseService) {}

  async findOne(findOneMasterTableDto: FindOneMasterTableDto) {
    console.log({ findOneMasterTableDto });
    const { id, name, parentId } = findOneMasterTableDto;

    if (id) {
      return await this.db.masterTable.findUnique({ where: { id } });
    }

    return await this.db.masterTable.findFirst({
      where: { parentId, name: { equals: name, mode: 'insensitive' } },
    });
  }

  async findFirst(findFirstMasterTableDto: FindFirstMasterTableDto) {
    const { parentId } = findFirstMasterTableDto;

    const record = await this.db.masterTable.findFirst({
      where: { parentId },
      orderBy: {
        order: 'asc',
      },
    });

    if (!record)
      throw new Error(`MasterTable record not found for parentId: ${parentId}`);

    return record;
  }
}
