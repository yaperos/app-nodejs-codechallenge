import { Module } from '@nestjs/common';
import { TransactionModule } from './external-transaction/external-transaction.module';
import { MasterTableModule } from './master-table/master-table.module';
import { KafkaModule } from './transports/kafka.module';
import { DatabaseModule } from './config';

@Module({
  imports: [DatabaseModule, TransactionModule, MasterTableModule, KafkaModule],
  controllers: [],
  providers: [],
})
export class AppModule {}
